function startApp() {
    alert("Let's build your routine together!");
}
